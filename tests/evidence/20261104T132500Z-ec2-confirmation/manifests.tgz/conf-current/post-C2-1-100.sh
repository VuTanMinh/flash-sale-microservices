set -uo pipefail
exec 2>&1
cd /opt/flash-sale-microservices
HOME=/root pwsh -NoProfile -File scripts/extract-run-metrics.ps1 -RunId 20261104T125201Z-C2-r1-100rps-rep1 -RunDir /tmp/matrix/20261104T125201Z-C2-r1-100rps-rep1 -Container infra-postgres-1 -From 2026-11-04T12:52:58.432Z -To 2026-11-04T12:53:58.347Z > /tmp/matrix/20261104T125201Z-C2-r1-100rps-rep1/extract.log 2>&1
echo "extract exit $?"
ls /tmp/matrix/20261104T125201Z-C2-r1-100rps-rep1 | tr '\n' ' '; echo
du -sh /tmp/matrix/20261104T125201Z-C2-r1-100rps-rep1 | cut -f1
docker ps -a --format '{{.Names}} {{.Status}}' | grep -v -E 'Up |migrate' || echo 'all containers up'
for c in $(docker ps -q); do docker inspect -f '{{.Name}} restarts={{.RestartCount}}' $c; done | grep -v 'restarts=0' || echo 'no restarts'
df -h / | tail -1 | awk '{print "disk " $5}'
docker logs --since 10m infra-postgres-1 2>&1 | grep -c 'too many clients' || true
for c in infra-order-service-1 infra-process-worker-1 infra-inventory-service-1; do docker inspect -f '{{range .Config.Env}}{{println .}}{{end}}' $c | grep -E '^(RabbitMQ__EventBus__ConsumerDispatchConcurrency|Reconciliation__StuckTimeoutSeconds|Processing__MaxConcurrency|RabbitMQ__EventBus__PrefetchCount|Admission__MaxOutboxBacklog|Admission__Enabled)=' | sed "s/^/ENV $c /"; done
docker exec infra-rabbitmq-1 rabbitmqctl -q list_policies --formatter json | tr -d '\n' | sed 's/^/POLICY /'; echo